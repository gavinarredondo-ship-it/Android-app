[app]
title = NSP Box
package.name = nspbox
package.domain = org.nspbox.android
source.dir = .
source.include_exts = py,md,txt,terms
source.exclude_dirs = .github,__pycache__,bin,.buildozer
version = 4.0.0
# If the zstandard build fails in CI, remove it: Game and DLC packaging still work, NUP tools won't.
requirements = python3,kivy==2.3.0,pillow,zstandard
orientation = portrait
fullscreen = 0
android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,MANAGE_EXTERNAL_STORAGE
android.api = 34
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
