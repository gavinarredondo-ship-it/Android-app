"""UI-independent operations for the Android app. Wraps the unmodified NSP Box engine."""
import re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / 'core'))
import engine, dlc
from artwork import ArtworkSelection

PRESETS = {'Fast': 1, 'Balanced': 3, 'Smaller': 9}
NUP_OPERATIONS = ('Folder → NUP', 'NSP → NUP', 'NUP → Folder', 'NUP → NSP', 'Inspect / Verify')
INCLUDE_GROUPS = {'Base': (0,), 'Updates': (1,), 'DLC': (2, 3)}

def _tools():
    try:
        import nup_tools  # needs zstandard; imported lazily so Game/DLC work without it
    except ImportError as e:
        raise RuntimeError('NUP tools need the zstandard package, which is missing from this build.') from e
    return nup_tools

def safe_name(text):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', text).rstrip('. ')[:110] or 'Output'

def unique(path):
    path = Path(path)
    if not path.exists():
        return path
    n = 2
    while True:
        c = path.with_name(f'{path.stem} ({n}){path.suffix}')
        if not c.exists():
            return c
        n += 1

def pretty_notify(callback):
    """Engine notify callbacks vary in arity; normalise to (message, percent|None)."""
    def notify(*a):
        msg = next((x for x in a if isinstance(x, str)), '')
        num = next((x for x in a if isinstance(x, (int, float)) and not isinstance(x, bool)), None)
        callback(msg, None if num is None else max(0.0, min(100.0, float(num))))
    return notify

# ---- Game ----
def scan_game(folder):
    snapshots, _warnings = engine.find_snapshots(folder)
    return snapshots

def game_defaults(s):
    if s.nacp:
        v = s.nacp.read_bytes()[0x3060:0x3070].split(b'\0')[0].decode('utf-8', 'replace')
    else:
        v = 'dump-' + str(s.version) if s.version else 'Snapshot'
    out = unique(s.root.parent / (safe_name(s.title) + '.nsp'))
    return s.title, v, str(out)

def build_game(s, output, title, version, artwork, verify, notify, cancel, package_folder=False):
    art = ArtworkSelection(Path(artwork)) if artwork else None
    return engine.build(s, output, title, version, art, verify, notify=pretty_notify(notify),
                        cancel=cancel, package_folder=package_folder)

# ---- DLC ----
def scan_dlc(folder, title_id=None, base_game=None):
    items = dlc.find_snapshots(folder, title_id or None)
    info = dlc.base_game_info(base_game) if base_game else None
    return items, info

def build_dlc(s, output, verify, base_game, notify, cancel):
    return dlc.build(s, output, 'nsp', verify, base_game or None, pretty_notify(notify), cancel)

# ---- NUP ----
def nup_output(path, op):
    src = Path(path).absolute()
    if src.name.lower() in ('exefs', 'romfs') and op == NUP_OPERATIONS[0]:
        src = src.parent
    if op == NUP_OPERATIONS[4]:
        return ''
    stem = src.name if op == NUP_OPERATIONS[0] else src.stem
    suffix = '.nup' if op in NUP_OPERATIONS[:2] else ('-NSP' if op == NUP_OPERATIONS[3] else '-extracted')
    return str(unique(src.parent / (stem + suffix)))

def scan_nup(path, op, notify, cancel):
    t = _tools(); n = pretty_notify(notify)
    if op == NUP_OPERATIONS[0]:
        prepared = t.prepare_folder(path, cancel, n)
        return {'packages_info': [{'index': i, 'kind': t_kind(p.kind), 'title_id': f'{p.title_id:016X}', 'version': p.version,
                                   'files': len(p.files)} for i, p in enumerate(prepared.packages)], '_prepared': prepared}
    if op == NUP_OPERATIONS[1]:
        with t.nsp_packages(path, cancel, n, deep=False) as packages:
            return {'packages_info': [{'index': i, 'kind': t_kind(p.kind), 'title_id': f'{p.title_id:016X}', 'version': p.version,
                                       'files': len(p.files)} for i, p in enumerate(packages)]}
    return t.inspect(path, cancel=cancel)

def t_kind(k):
    from nup_format import KINDS
    return KINDS[k]

def run_nup(op, path, output, preset, large_raw, latest, verify, kinds, prepared, notify, cancel):
    t = _tools(); common = {'notify': pretty_notify(notify), 'cancel': cancel}
    if op == NUP_OPERATIONS[0]:
        return t.pack_folder(path, output, level=PRESETS[preset], large_raw=large_raw, latest_snapshot=latest,
                             prepared=prepared, verify=verify, include_kinds=kinds, **common)
    if op == NUP_OPERATIONS[1]:
        return t.nsp_to_nup(path, output, level=PRESETS[preset], large_raw=large_raw, verify=verify, include_kinds=kinds, **common)
    if op == NUP_OPERATIONS[2]:
        from nup_format import Archive
        with Archive(path, cancel) as archive:
            sel = [i for i, p in enumerate(archive.packages) if p.kind in kinds]
        return t.extract(path, output, selection=sel, **common)
    if op == NUP_OPERATIONS[3]:
        return t.nup_to_nsp(path, output, include_kinds=kinds, verify=verify, **common)
    return t.inspect(path, verify=verify, **common)
