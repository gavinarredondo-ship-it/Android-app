# NSP Box for Android (unofficial port)

A Kivy touch front-end around the **unmodified** NSP Box 4.0.0 packaging engine (MIT, see LICENSE.txt),
which lives in `core/`. Features: Game → NSP, DLC → NSP, and NUP tools (folder/NSP → NUP, NUP → NSP,
NUP → folder, inspect/verify), with progress, cancel, verification and no-overwrite numbered outputs.

Not ported: the emulator patcher (it edits Windows x64 executables) and the placeholder-key setup.

## Build the APK
Push this folder to a GitHub repo; the `Build Android APK` workflow runs the tests and builds
`bin/*.apk` (artifact `NSP-Box-debug-apk`). Locally on Linux: `pip install buildozer cython<3` then `buildozer android debug`.
If the `zstandard` dependency fails to build, remove it from `requirements` in `buildozer.spec`;
Game and DLC packaging then work and NUP tools report that zstandard is missing.

## Notes
- On Android 11+, grant "All files access" on first launch: the engine needs real file paths.
- Checked here: `python test_ops.py` (synthetic game build, verification, cancel cleanup) and the
  upstream engine/artwork/performance tests on Linux. NOT checked: the Kivy UI on a device, the APK
  build, and NUP (zstandard wasn't installable in the sandbox).
