"""NSP Box for Android: touch front-end for the unmodified NSP Box packaging engine."""
import os, threading
from pathlib import Path
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.uix.textinput import TextInput
import ops

ROOT = '/storage/emulated/0'
NOTICE = ('Experimental. Use only game files and artwork you lawfully obtained. Nothing here decrypts content; '
          'no games, keys or firmware are included. Not affiliated with Nintendo.')

def ensure_storage():
    """Real filesystem paths are needed (mmap, streaming), so request All-files access on Android 11+."""
    try:
        from jnius import autoclass
        VERSION = autoclass('android.os.Build$VERSION')
        if VERSION.SDK_INT >= 30:
            Env = autoclass('android.os.Environment')
            if not Env.isExternalStorageManager():
                Intent = autoclass('android.content.Intent'); Settings = autoclass('android.provider.Settings')
                Uri = autoclass('android.net.Uri'); act = autoclass('org.kivy.android.PythonActivity').mActivity
                i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                i.setData(Uri.parse('package:' + act.getPackageName())); act.startActivity(i)
        else:
            from android.permissions import request_permissions, Permission
            request_permissions([Permission.READ_EXTERNAL_STORAGE, Permission.WRITE_EXTERNAL_STORAGE])
    except Exception:
        pass  # not on Android (desktop testing)

def wrap(text='', **kw):
    l = Label(text=text, halign='left', valign='top', size_hint_y=None, **kw)
    l.bind(width=lambda i, w: setattr(i, 'text_size', (w, None)))
    l.bind(texture_size=lambda i, s: setattr(i, 'height', s[1] + dp(6)))
    return l

def button(text, cb, **kw):
    b = Button(text=text, size_hint_y=None, height=dp(46), **kw); b.bind(on_release=lambda *_: cb()); return b

def pick(title, mode, on_pick, exts=None):
    start = ROOT if os.path.isdir(ROOT) else str(Path.home())
    chooser = FileChooserListView(path=start, dirselect=(mode == 'dir'), filters=[lambda d, f: os.path.isdir(os.path.join(d, f)) or not exts or f.lower().endswith(exts)])
    box = BoxLayout(orientation='vertical', spacing=dp(6)); box.add_widget(chooser)
    popup = Popup(title=title, content=box, size_hint=(0.96, 0.92))
    def accept():
        value = chooser.path if mode == 'dir' else (chooser.selection[0] if chooser.selection else '')
        if mode == 'dir' and chooser.selection: value = chooser.selection[0]
        if value: popup.dismiss(); on_pick(value)
    row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(6))
    row.add_widget(button('Cancel', popup.dismiss)); row.add_widget(button('Use folder' if mode == 'dir' else 'Use file', accept))
    box.add_widget(row); popup.open()

def check(text, active=True):
    row = BoxLayout(size_hint_y=None, height=dp(40)); cb = CheckBox(active=active, size_hint_x=None, width=dp(44))
    row.add_widget(cb); row.add_widget(Label(text=text, halign='left')); row.children[0].bind(size=lambda i, s: setattr(i, 'text_size', s))
    return row, cb

def report(data):
    lines = []
    for k, v in data.items():
        if k.startswith('_') or isinstance(v, (list, dict)): continue
        lines.append(f'{k}: {v}')
    return '\n'.join(lines)

class Panel(BoxLayout):
    def __init__(self):
        super().__init__(orientation='vertical', spacing=dp(8), padding=dp(10))
        self.cancel = threading.Event(); self.busy = False; self.controls = []
        scroll = ScrollView(); self.form = BoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(8))
        self.form.bind(minimum_height=self.form.setter('height')); scroll.add_widget(self.form); self.add_widget(scroll)
        self.bar = ProgressBar(max=100, size_hint_y=None, height=dp(8)); self.add_widget(self.bar)
        self.status = Label(text='Ready', size_hint_y=None, height=dp(40), halign='left', shorten=True)
        self.status.bind(size=lambda i, s: setattr(i, 'text_size', s)); self.add_widget(self.status)
        self.cancel_btn = button('Cancel', lambda: self.cancel.set(), disabled=True); self.add_widget(self.cancel_btn)
        self.form.add_widget(wrap(NOTICE, font_size='12sp'))

    def add(self, w, control=True):
        self.form.add_widget(w)
        if control: self.controls.append(w)
        return w

    def set_busy(self, busy):
        self.busy = busy; self.cancel_btn.disabled = not busy
        for c in self.controls: c.disabled = busy

    def run(self, work, done, label):
        if self.busy: return
        self.cancel = threading.Event(); cancel = self.cancel
        self.set_busy(True); self.bar.value = 0; self.status.text = label
        def notify(msg, pct): Clock.schedule_once(lambda dt: self._progress(msg, pct))
        def target():
            try: r = work(notify, cancel); err = None
            except Exception as e: r = None; err = e
            Clock.schedule_once(lambda dt: self._finish(done, r, err))
        threading.Thread(target=target, daemon=True).start()

    def _progress(self, msg, pct):
        if msg: self.status.text = msg
        if pct is not None: self.bar.value = pct

    def _finish(self, done, result, err):
        self.set_busy(False)
        if isinstance(err, InterruptedError): self.status.text = 'Cancelled. Unfinished output was removed.'
        elif err is not None: self.status.text = 'Error: ' + str(err)
        else: self.bar.value = 100; done(result)

    def show(self, text):
        popup = Popup(title='Result', size_hint=(0.94, 0.7), content=BoxLayout(orientation='vertical'))
        sv = ScrollView(); sv.add_widget(wrap(text)); popup.content.add_widget(sv)
        popup.content.add_widget(button('Close', popup.dismiss)); popup.open()

class GamePanel(Panel):
    def __init__(self):
        super().__init__(); self.snaps = []; self.art = None
        self.add(button('Choose game dump folder', lambda: pick('Game dump folder', 'dir', self.set_folder)))
        self.folder = self.add(wrap('No folder selected'), False)
        self.combo = self.add(Spinner(text='Snapshot', values=[], size_hint_y=None, height=dp(46))); self.combo.bind(text=self.select)
        self.title = self.add(TextInput(hint_text='Game title', multiline=False, size_hint_y=None, height=dp(44)))
        self.version = self.add(TextInput(hint_text='Display version (max 15 bytes)', multiline=False, size_hint_y=None, height=dp(44)))
        self.add(button('Choose artwork (optional)', lambda: pick('Artwork', 'file', self.set_art, ('.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif', '.tif', '.tiff'))))
        self.art_label = self.add(wrap('Artwork: none (center-cropped to 256×256 if chosen)'), False)
        self.output = self.add(wrap('Output: choose a snapshot'), False)
        row, self.verify = check('Verify after building'); self.add(row)
        row, self.pkgfolder = check('Create package folder (companion main.npdm + report)'); self.add(row)
        self.build_btn = self.add(button('Build NSP', self.build))

    def set_folder(self, p):
        self.folder.text = p; self.status.text = 'Scanning for complete snapshots…'
        self.run(lambda n, c: ops.scan_game(p), self.scanned, 'Scanning…')
    def scanned(self, snaps):
        self.snaps = snaps; self.combo.values = [f'{s.label}  ·  {s.title_id:016X}' for s in snaps]
        if snaps: self.combo.text = self.combo.values[0]
        self.status.text = f'{len(snaps)} snapshot(s) found' if snaps else 'No complete snapshot found'
    def select(self, _, text):
        if text in self.combo.values:
            s = self.snaps[self.combo.values.index(text)]; t, v, o = ops.game_defaults(s)
            self.title.text, self.version.text = t, v; self.output.text = 'Output: ' + o
    def set_art(self, p): self.art = p; self.art_label.text = 'Artwork: ' + Path(p).name
    def build(self):
        if self.combo.text not in self.combo.values: self.status.text = 'Choose a game folder first.'; return
        s = self.snaps[self.combo.values.index(self.combo.text)]; out = ops.game_defaults(s)[2]
        title, ver, art, verify, pf = self.title.text, self.version.text, self.art, self.verify.active, self.pkgfolder.active
        self.run(lambda n, c: ops.build_game(s, out, title, ver, art, verify, n, c, pf), lambda r: (self.show(report(r)), setattr(self.status, 'text', 'Done')), 'Building…')

class DlcPanel(Panel):
    def __init__(self):
        super().__init__(); self.items = []; self.base = ''
        self.add(button('Choose extracted DLC folder', lambda: pick('DLC folder', 'dir', self.set_folder)))
        self.folder = self.add(wrap('No folder selected'), False)
        self.add(button('Base game NSP (optional check)', lambda: pick('Base NSP', 'file', self.set_base, ('.nsp',))))
        self.base_label = self.add(wrap('Base game: none'), False)
        self.tid = self.add(TextInput(hint_text='DLC title ID (only if missing from folder names)', multiline=False, size_hint_y=None, height=dp(44)))
        self.combo = self.add(Spinner(text='DLC package', values=[], size_hint_y=None, height=dp(46)))
        self.version = self.add(TextInput(hint_text='Numeric version (optional override)', multiline=False, size_hint_y=None, height=dp(44)))
        row, self.verify = check('Verify after building'); self.add(row)
        self.add(button('Rescan', self.scan)); self.add(button('Build DLC NSP', self.build))
    def set_folder(self, p): self.folder.text = p; self.scan()
    def set_base(self, p): self.base = p; self.base_label.text = 'Base game: ' + Path(p).name
    def scan(self):
        f, t, b = self.folder.text, self.tid.text.strip(), self.base
        if not os.path.isdir(f): self.status.text = 'Choose a DLC folder first.'; return
        self.run(lambda n, c: ops.scan_dlc(f, t, b), self.scanned, 'Scanning…')
    def scanned(self, result):
        self.items = result[0]; self.combo.values = [f'{s.label} · {s.title_id:016X} · v{s.version}' for s in self.items]
        if self.items: self.combo.text = self.combo.values[0]
        self.status.text = f'{len(self.items)} DLC package(s) found' if self.items else 'No DLC found'
    def build(self):
        if self.combo.text not in self.combo.values: self.status.text = 'Scan a DLC folder first.'; return
        import dlc
        o = self.items[self.combo.values.index(self.combo.text)]
        v = dlc.parse_version(self.version.text) if self.version.text.strip() else o.version
        s = dlc.DlcSnapshot(o.root, o.title_id, v, o.label)
        out = str(ops.unique(o.root.parent / (ops.safe_name(o.label) + '-DLC.nsp'))); verify, base = self.verify.active, self.base
        self.run(lambda n, c: ops.build_dlc(s, out, verify, base, n, c), lambda r: (self.show(report(r)), setattr(self.status, 'text', 'Done')), 'Building…')

class NupPanel(Panel):
    def __init__(self):
        super().__init__(); self.catalog = []; self.prepared = None; self.source = ''
        self.op = self.add(Spinner(text=ops.NUP_OPERATIONS[0], values=ops.NUP_OPERATIONS, size_hint_y=None, height=dp(46))); self.op.bind(text=lambda *_: self.reset())
        self.add(button('Choose input', self.choose)); self.input = self.add(wrap('No input selected'), False)
        self.preset = self.add(Spinner(text='Balanced', values=tuple(ops.PRESETS), size_hint_y=None, height=dp(46)))
        self.kinds = {}
        for name in ops.INCLUDE_GROUPS:
            row, cb = check('Include ' + name); self.add(row); self.kinds[name] = cb
        row, self.raw = check('Store files over 256 MiB uncompressed'); self.add(row)
        row, self.latest = check('Latest-snapshot mode (folder packing)'); self.add(row)
        row, self.verify = check('Verify'); self.add(row)
        self.add(button('Inspect source', self.scan)); self.add(button('Start', self.start))
    def reset(self): self.catalog = []; self.prepared = None
    def choose(self):
        op = self.op.text
        if op == ops.NUP_OPERATIONS[0]: pick('Source folder', 'dir', self.set_input)
        else: pick('Input file', 'file', self.set_input, ('.nsp',) if op == ops.NUP_OPERATIONS[1] else ('.nup',))
    def set_input(self, p): self.source = p; self.input.text = p; self.reset(); self.scan()
    def scan(self):
        if not self.source: self.status.text = 'Choose an input first.'; return
        p, op = self.source, self.op.text
        self.run(lambda n, c: ops.scan_nup(p, op, n, c), self.scanned, 'Inspecting…')
    def scanned(self, data):
        self.prepared = data.pop('_prepared', None); self.catalog = data.get('packages_info', [])
        self.status.text = f'{len(self.catalog)} package(s) found' if self.catalog else 'Inspection complete'
        if self.op.text == ops.NUP_OPERATIONS[4]: self.show(report(data))
    def start(self):
        op, p = self.op.text, self.source
        if not p: self.status.text = 'Choose an input first.'; return
        if op != ops.NUP_OPERATIONS[4] and not self.catalog: self.scan(); return
        names = {'base': 0, 'update': 1, 'addon': 2, 'addon_update': 3}
        available = {names.get(c['kind']) for c in self.catalog}
        kinds = {k for n, cb in self.kinds.items() if cb.active for k in ops.INCLUDE_GROUPS[n] if k in available}
        if op != ops.NUP_OPERATIONS[4] and not kinds: self.status.text = 'Select Base, Updates or DLC.'; return
        out = ops.nup_output(p, op); prep = self.prepared
        if prep is not None and Path(prep.root) != Path(p).resolve(): prep = None
        args = (op, p, out, self.preset.text, self.raw.active, self.latest.active, self.verify.active, kinds, prep)
        self.run(lambda n, c: ops.run_nup(*args, n, c), lambda r: (self.show(report(r) + ('\n\nSaved: ' + out if out else '')), setattr(self.status, 'text', 'Done')), 'Working…')

class NspBoxApp(App):
    title = 'NSP Box'
    def build(self):
        ensure_storage()
        tabs = TabbedPanel(do_default_tab=False, tab_width=dp(110))
        for name, cls in (('Game', GamePanel), ('DLC', DlcPanel), ('NUP', NupPanel)):
            item = TabbedPanelItem(text=name); item.add_widget(cls()); tabs.add_widget(item)
        tabs.default_tab = tabs.tab_list[-1]
        return tabs

if __name__ == '__main__':
    NspBoxApp().run()
