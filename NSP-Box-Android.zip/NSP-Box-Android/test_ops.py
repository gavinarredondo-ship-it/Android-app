"""Headless checks of the Android operation layer using synthetic data (no game files)."""
import struct, tempfile, threading, unittest
from pathlib import Path
from PIL import Image
import ops

class OpsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
        self.game = self.root / 'Example Game [0400111122220000]'
        for v in (65536, 131072):
            p = self.game / 'updates' / str(v); (p / 'exefs').mkdir(parents=True); (p / 'romfs').mkdir(parents=True)
            npdm = bytearray(0x100); npdm[:4] = b'META'; struct.pack_into('<II', npdm, 0x70, 0x80, 0x80)
            npdm[0x80:0x84] = b'ACI0'; struct.pack_into('<Q', npdm, 0x90, 0x0400111122220000)
            (p / 'exefs/main.npdm').write_bytes(npdm); (p / 'exefs/main').write_bytes(b'NSO0' + bytes(256))
            (p / 'romfs/data.bin').write_bytes(bytes(range(256)) * 300)
        self.art = self.root / 'art.png'; Image.new('RGB', (400, 300), (10, 80, 160)).save(self.art)
    def tearDown(self): self.tmp.cleanup()

    def test_scan_and_build(self):
        snaps = ops.scan_game(str(self.game)); self.assertEqual(snaps[0].version, 131072)
        title, version, out = ops.game_defaults(snaps[0])
        events = []
        r = ops.build_game(snaps[0], out, title, version, str(self.art), True,
                           lambda m, p: events.append((m, p)), threading.Event())
        self.assertTrue(r['verified']); self.assertTrue(Path(out).is_file()); self.assertTrue(events)
        self.assertNotEqual(ops.game_defaults(snaps[0])[2], out)  # numbered, never overwrites

    def test_cancel_removes_output(self):
        snaps = ops.scan_game(str(self.game)); cancel = threading.Event(); cancel.set()
        out = self.root / 'c.nsp'
        with self.assertRaises(InterruptedError):
            ops.build_game(snaps[0], str(out), 'T', '1', None, True, lambda *a: None, cancel)
        self.assertFalse(out.exists())

if __name__ == '__main__':
    unittest.main()
